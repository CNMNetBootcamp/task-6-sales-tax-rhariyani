////set up

//note: all in green commnets because program show run time error due to this file

double ordertotal = 0.0;
double totaltax = 0.0;
double grandtotal = 0.0;
double statetax = 0.0;
double salestax = 0.0;
double tax1 = 0.03;
double tax2 = 0.05;

////input

//    "What is your odertotal?";


//    //process

//    salestax=ordertotal*tax1 
//put "The salestax is:"+Salestax
//    statetax=ordertotal*tax2           
//put "The statetax is:"+statetax

//    totaltax amt = salestax + statetax;
//put "The total tax amt is:"+taotal tax
//    grandtotal=totaltax+ordertotal;
//put "The grandtotal is:"+grandtotal
//    


