## Task 6 ##
### Sales Tax ###
Create a program that calculates the state and local sales tax on an order. The user should be asked what the order total was. The tax calculation should be done using a module and the tax percentage passed in. State tax is 5% and local tax is 3%. Output to the screen the subtotal, the taxes amounts and the grand total.
